# src/llm_based.py
"""
LLM 기반 PII 탐지 (Ollama + llama3.2:3b)
"""
import ollama
import json
import re

PROMPT_TEMPLATE = """You are an expert PII/NER detection system for European Court of Human Rights (ECHR) legal documents.

Extract ALL named entities and personally identifiable information. Be thorough - find every instance.

Categories to detect:
- PERSON: full names (Mr John Smith), initials (A.H.), single surnames, judges, applicants, lawyers
- ORG: courts, governments, companies, institutions, ministries, political parties
- LOC: countries, cities, regions, addresses, geographical places
- DATE: all dates, years (1994), decades (1990s), date ranges, months, seasons with years
- CODE: case numbers (36244/06), article numbers, application numbers
- DEM: nationalities, ethnicities (Danish, Turkish, Polish)
- QUANTITY: ages, durations, monetary amounts
- MISC: any other identifying information

Return ONLY a JSON array. Each item: {{"text": "exact string", "type": "CATEGORY"}}
Do NOT include start/end indices. Find ALL instances, not just the first occurrence.
If no PII found, return [].

Text:
{text}"""

CHUNK_SIZE = 2000
CHUNK_OVERLAP = 200


def _call_llm(text_chunk: str, model: str) -> list:
    response = ollama.chat(
        model=model,
        messages=[{"role": "user",
                    "content": PROMPT_TEMPLATE.format(text=text_chunk)}],
        options={"temperature": 0, "num_ctx": 4096}
    )
    raw = response["message"]["content"]
    raw = re.sub(r"```(?:json)?|```", "", raw).strip()

    # 배열만 추출 (LLM이 부연 설명을 덧붙이는 경우)
    bracket_start = raw.find("[")
    bracket_end = raw.rfind("]")
    if bracket_start != -1 and bracket_end != -1:
        raw = raw[bracket_start:bracket_end + 1]

    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return []


def detect_llm(text: str, model: str = "llama3.2:3b") -> list:
    if len(text) <= CHUNK_SIZE:
        raw_items = _call_llm(text, model)
    else:
        raw_items = []
        pos = 0
        while pos < len(text):
            end = min(pos + CHUNK_SIZE, len(text))
            chunk = text[pos:end]
            raw_items.extend(_call_llm(chunk, model))
            pos += CHUNK_SIZE - CHUNK_OVERLAP

    seen_positions = set()
    verified = []
    for item in raw_items:
        span_text = item.get("text", "").strip()
        if not span_text or len(span_text) < 2:
            continue
        pii_type = item.get("type", "MISC")
        start = 0
        while True:
            idx = text.find(span_text, start)
            if idx == -1:
                break
            pos_key = (idx, idx + len(span_text))
            if pos_key not in seen_positions:
                seen_positions.add(pos_key)
                verified.append({
                    "text":  span_text,
                    "type":  pii_type,
                    "start": idx,
                    "end":   idx + len(span_text),
                })
            start = idx + 1
    return verified