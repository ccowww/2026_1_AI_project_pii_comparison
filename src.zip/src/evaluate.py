# src/evaluate.py
"""
Rule-based vs LLM-based 결과 비교 및 F1 평가
"""
import csv
import logging
from datetime import datetime
from pathlib import Path

TYPE_MAP = {
    # Rule-based 예측 타입
    "NAME_CONTEXT": "PERSON",
    "SSN":          "CODE",
    "PHONE":        "CONTACT",
    "TEL":          "CONTACT",
    "EMAIL":        "CONTACT",
    # LLM/Rule 공통
    "DATE":         "DATE",
    "ID":           "CODE",
    "CONTACT":      "CONTACT",
    # TAB gold 라벨 타입
    "PERSON":       "PERSON",
    "LOC":          "LOC",
    "ORG":          "ORG",
    "MISC":         "MISC",
    "CODE":         "CODE",
    "DATETIME":     "DATE",
    "DEM":          "DEM",
    "QUANTITY":     "QUANTITY",
}

def spans_to_set(preds: list) -> set:
    """(start, end, normalized_type) 기준 집합으로 변환"""
    result = set()
    for p in preds:
        if p.get("start") is None or p.get("end") is None:
            continue
        raw_type = p.get("type", "MISC")
        norm_type = TYPE_MAP.get(raw_type, "MISC")
        result.add((p["start"], p["end"], norm_type))
    return result

def compute_f1(pred_spans: set, gold_spans: set) -> dict:
    tp = len(pred_spans & gold_spans)
    fp = len(pred_spans - gold_spans)
    fn = len(gold_spans - pred_spans)

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1        = (2 * precision * recall / (precision + recall)
                 if (precision + recall) > 0 else 0.0)

    return {"precision": precision, "recall": recall,
            "f1": f1, "tp": tp, "fp": fp, "fn": fn}

def evaluate_all(samples: list, rule_preds: list,
                 llm_preds: list, results_dir: Path):

    rule_scores, llm_scores = [], []

    for i, sample in enumerate(samples):
        gold = spans_to_set(sample["labels"])
        rule_scores.append(compute_f1(spans_to_set(rule_preds[i]), gold))
        llm_scores.append( compute_f1(spans_to_set(llm_preds[i]),  gold))

    def avg(scores, key):
        return sum(s[key] for s in scores) / len(scores)

    # 콘솔 출력
    logging.info("\n" + "=" * 50)
    logging.info("최종 결과 비교")
    logging.info("=" * 50)
    logging.info(f"{'방법':>12} {'Precision':>10} {'Recall':>10} {'F1':>10}")
    logging.info("-" * 50)
    for method, scores in [("Rule-based", rule_scores), ("LLM-based", llm_scores)]:
        logging.info(
            f"{method:>12} "
            f"{avg(scores, 'precision'):>10.3f} "
            f"{avg(scores, 'recall'):>10.3f} "
            f"{avg(scores, 'f1'):>10.3f}"
        )
    logging.info("=" * 50)

    # CSV 저장
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path  = results_dir / f"pii_comparison_{timestamp}.csv"

    rows = []
    for i in range(len(samples)):
        rows.append({
            "sample_idx":       i,
            "method":           "rule",
            "precision":        round(rule_scores[i]["precision"], 3),
            "recall":           round(rule_scores[i]["recall"],    3),
            "f1":               round(rule_scores[i]["f1"],        3),
            "tp":               rule_scores[i]["tp"],
            "fp":               rule_scores[i]["fp"],
            "fn":               rule_scores[i]["fn"],
        })
        rows.append({
            "sample_idx":       i,
            "method":           "llm",
            "precision":        round(llm_scores[i]["precision"],  3),
            "recall":           round(llm_scores[i]["recall"],     3),
            "f1":               round(llm_scores[i]["f1"],         3),
            "tp":               llm_scores[i]["tp"],
            "fp":               llm_scores[i]["fp"],
            "fn":               llm_scores[i]["fn"],
        })

    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(
            f, fieldnames=["sample_idx","method","precision","recall","f1","tp","fp","fn"])
        writer.writeheader()
        writer.writerows(rows)

    logging.info(f"결과 CSV 저장 완료: {csv_path}")