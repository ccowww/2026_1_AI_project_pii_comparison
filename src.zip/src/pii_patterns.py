# src/pii_patterns.py
"""
[PII Pattern Definitions - English Version]
영어 텍스트에서 탐지할 PII 정규표현식 룰
"""
import re

# (1) US Social Security Number
ssn_pattern = re.compile(r'\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b')

# (2) US Mobile Phone
phone_pattern = re.compile(
    r'\b(\+?1[-.\s]?)?(\(?\d{3}\)?)[-.\s]?\d{3}[-.\s]?\d{4}\b'
)

# (3) Toll-free / Landline
tel_pattern = re.compile(
    r'\b(?:800|888|877|866|855|844|833)[-.\s]\d{3}[-.\s]\d{4}\b'
)

# (4) 이메일
email_pattern = re.compile(
    r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b'
)

# (5) 인명 패턴 - 호칭 포함 + 호칭 없는 대문자 이름 + 이니셜
_TITLES = r'(?:Mr|Mrs|Ms|Miss|Dr|Prof|Rev|Hon|Sir|Lady|Lord|Judge|President)'
name_pattern = re.compile(
    r'(?:'
    + _TITLES + r'\.?\s+'
    r'(?:[A-Z]\.?\s+)*'
    r'[A-Z\u00C0-\u024F][a-z\u00C0-\u024F]+(?:[-\s]+[A-Z\u00C0-\u024F][a-z\u00C0-\u024F]+)*'
    r'|'
    r'[A-Z]\.[A-Z]\.'
    r'|[A-Z]\.\s+[A-Z\u00C0-\u024F][a-z\u00C0-\u024F]+'
    r')',
    re.UNICODE
)

# (6) 날짜 (TAB 데이터셋 DATETIME 유형 대응)
_MONTHS = (
    r'(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?'
    r'|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)'
)
_SEASONS = r'(?:spring|summer|autumn|winter)'
_RELATIVE_TIME = r'(?:beginning|end|start|middle)'

date_pattern = re.compile(
    r'\b(?:'
    # DD/MM/YYYY or DD-MM-YYYY
    r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}'
    # "12 March 1970"
    r'|\d{1,2}\s+' + _MONTHS + r'\s+(?:19|20)\d{2}'
    # "March 1970" or "March 12, 1970"
    r'|' + _MONTHS + r'(?:\.?\s+\d{1,2},?)?\s+(?:19|20)\d{2}'
    # 연대 표현: "1990s", "late 1980s"
    r'|(?:late\s+|early\s+|mid[-\s])?(?:19|20)\d{2}s'
    # 계절/시기 + 연도: "summer of 1993", "beginning of 1996", "autumn 2002"
    r'|(?:' + _SEASONS + r'|' + _RELATIVE_TIME + r')(?:\s+of)?\s+(?:the\s+)?(?:19|20)\d{2}(?:s)?'
    # 월 단독: "February", "November"
    r'|' + _MONTHS +
    # 연도 단독: 1970, 2003
    r'|(?:19|20)\d{2}'
    r')\b',
    re.IGNORECASE
)

# 화이트리스트 (오탐 방지)
EXCLUDED_WORDS = {
    "Mr", "Mrs", "Ms", "Miss", "Dr", "Prof", "Rev", "Hon",
    "Sir", "Lady", "Lord", "Judge", "President",
    "May",
}

# 스캐너가 사용할 패턴 딕셔너리
PII_PATTERNS = {
    "SSN":          ssn_pattern,
    "PHONE":        phone_pattern,
    "TEL":          tel_pattern,
    "EMAIL":        email_pattern,
    "NAME_CONTEXT": name_pattern,
    "DATE":         date_pattern,
}